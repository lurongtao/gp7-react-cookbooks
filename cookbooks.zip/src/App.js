import React, { Component } from 'react'

import { Home } from 'pages/home'

class App extends Component {
  render() {
    return (
      <Home></Home>
    )
  }
}

export default App;
