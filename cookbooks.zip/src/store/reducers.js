import { combineReducers } from 'redux'

import { reducer as cookbook } from 'pages/cookbook'

export default combineReducers({
  cookbook
})