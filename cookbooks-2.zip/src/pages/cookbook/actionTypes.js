export const GET_CATEGORY_DATA = 'cookbook/get_category_data'
export const GET_LIST_DATA = 'cookbook/get_list_data'